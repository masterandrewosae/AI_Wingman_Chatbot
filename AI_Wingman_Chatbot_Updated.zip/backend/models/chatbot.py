import openai

openai.api_key = "YOUR_OPENAI_API_KEY"

def generate_responses(user_input):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "You are an AI wingman helping users talk to girls smoothly. Provide three response options: playful, flirty, and casual."},
                  {"role": "user", "content": user_input}]
    )
    
    choices = response["choices"][0]["message"]["content"].split("\n")
    return {"playful": choices[0], "flirty": choices[1], "casual": choices[2]}
