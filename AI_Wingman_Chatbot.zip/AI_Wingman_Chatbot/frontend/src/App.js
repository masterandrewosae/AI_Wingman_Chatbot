import React, { useState } from 'react';
import axios from 'axios';

function App() {
    const [inputText, setInputText] = useState('');
    const [responses, setResponses] = useState([]);

    const handleAnalyze = async () => {
        const res = await axios.post('http://localhost:8000/analyze_message/', { text: inputText });
        setResponses(res.data.responses);
    };

    return (
        <div style={{ textAlign: 'center', padding: '20px' }}>
            <h1>AI Wingman Chatbot</h1>
            <textarea value={inputText} onChange={(e) => setInputText(e.target.value)} placeholder="Paste conversation here..." />
            <button onClick={handleAnalyze}>Get Responses</button>

            {responses.length > 0 && (
                <div>
                    <h2>Suggested Replies:</h2>
                    <ul>
                        <li><strong>Playful:</strong> {responses.playful}</li>
                        <li><strong>Flirty:</strong> {responses.flirty}</li>
                        <li><strong>Casual:</strong> {responses.casual}</li>
                    </ul>
                </div>
            )}
        </div>
    );
}

export default App;
