from fastapi import APIRouter, UploadFile, File
from models.chatbot import generate_responses
import pytesseract
from PIL import Image
import io

chat_router = APIRouter()

@chat_router.post("/analyze_message/")
async def analyze_message(text: str):
    responses = generate_responses(text)
    return {"responses": responses}

@chat_router.post("/upload_screenshot/")
async def upload_screenshot(file: UploadFile = File(...)):
    image = Image.open(io.BytesIO(await file.read()))
    extracted_text = pytesseract.image_to_string(image)
    responses = generate_responses(extracted_text)
    return {"extracted_text": extracted_text, "responses": responses}
